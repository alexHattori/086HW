commentA10P4 = '1242';
% curmean = 1/5;
% zscore = 2;
% n = 1000000;
% CI = [curmean+zscore^2/(2*n)-zscore*sqrt(curmean*(1-curmean)/n+zscore^2/(4*n^2))/(1+zscore^2/n),curmean+zscore^2/(2*n)+zscore*sqrt(curmean*(1-curmean)/n+zscore^2/(4*n^2))/(1+zscore^2/n)];
