[p_all,p_atleastone,N_points] = guesser(quest_attributes)
