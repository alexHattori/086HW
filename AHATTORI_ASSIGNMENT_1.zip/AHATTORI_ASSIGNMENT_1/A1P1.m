Q = 0;
for a = 1:N
    Q = Q+(1/(a^2));
end
