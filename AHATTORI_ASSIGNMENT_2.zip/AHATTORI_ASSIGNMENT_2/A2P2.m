[val,i_star] = max(x_vec(x_vec<x));

